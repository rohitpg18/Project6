from django.db import models
from django.dispatch import receiver
from django.db.models.signals import post_save

# Create your models here.


class Product(models.Model):
    model_name = models.CharField(max_length=255)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    total_quantity = models.IntegerField()
    remaining_quantity = models.IntegerField()
    published_date = models.DateField(auto_now_add=True)
    is_available = models.BooleanField(default=True)
    
    def __str__(self):
        return self.model_name
    
    
class Customer(models.Model):
    product = models.ForeignKey(Product,on_delete=models.CASCADE,related_name="product_customers")
    customer_name = models.CharField(max_length=255)
    price = models.IntegerField()
    purchase_date = models.DateField(auto_now_add=True)
    
    def __str__(self):
        return self.customer_name
    
    
class Sale(models.Model):
    
    product = models.OneToOneField(Product,on_delete=models.CASCADE,related_name="product_sales")
    total_sells = models.IntegerField(default=0)
    total_selling_price= models.IntegerField(default=0)
    
    def __str__(self):
        return self.product.model_name
    
    
@receiver(post_save, sender=Product)
def update_sale_signal(sender, instance, created, **kwargs):
    if created:
        a=Sale.objects.create(product=instance)
        a.save()