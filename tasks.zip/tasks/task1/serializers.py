from rest_framework import serializers
from .models import Product,Customer,Sale


class CustomerSer(serializers.ModelSerializer):
    class Meta:
        model = Customer
        fields = "__all__"
        
        
class SaleSer(serializers.ModelSerializer):
    class Meta:
        model = Sale
        fields = ['total_sells','total_selling_price']
        
        
class ProductDetailsSer(serializers.ModelSerializer):
    product_sales = SaleSer(many=False, read_only=True)

    class Meta:
        model = Product
        fields = ['id','model_name', 'price',  'total_quantity', 'remaining_quantity','published_date','is_available','product_sales']