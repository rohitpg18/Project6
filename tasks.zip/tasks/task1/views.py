from django.shortcuts import render
from django.http import HttpResponse
from rest_framework.response import Response  
from rest_framework.views import APIView
from .serializers import CustomerSer,SaleSer,ProductDetailsSer
from .models import Product,Customer,Sale
from rest_framework import status

# Create your views here.
class Products(APIView):
    def get(self, request):
        prd= Product.objects.all()
        ser = ProductDetailsSer(prd, many=True)
        return Response({'status':'success', 'Products':ser.data}, status=status.HTTP_200_OK)

    def post(self, request, format=None):
        serializer = CustomerSer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            
            print(serializer.data)
            
            p_id = serializer.data['product']
            
            p_price = serializer.data['price']
            
            prd = Product.objects.get(id = p_id)
            sale = Sale.objects.get(product = p_id)
            
            prd.remaining_quantity = prd.remaining_quantity -1
            
            sale.total_sells = sale.total_sells + 1
            sale.total_selling_price = sale.total_selling_price + int(p_price)
            
            prd.save()
            sale.save()
            
            return Response({'status':'success', 'Products':serializer.data}, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)