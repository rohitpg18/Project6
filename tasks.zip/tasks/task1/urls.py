
from django.urls import path,include
from . import views
from .views import Products
urlpatterns = [
    path("Products/",Products.as_view(),name="Products"),
    # path("Products/<int:pk>",Employee.as_view(),name="Employee"),
]
